package com.db4odoc.crossplatform;

import com.db4o.ObjectContainer;
import com.db4o.config.DotnetSupport;
import com.db4o.config.WildcardAlias;
import com.db4o.cs.Db4oClientServer;
import com.db4o.cs.config.ClientConfiguration;


public class JavaClient {
    public static void main(String[] args) throws Exception {
        ClientConfiguration configuration = Db4oClientServer.newClientConfiguration();
        configuration.common().add(new DotnetSupport(true));

        // #example: You need to add aliases for your types
        configuration.common().addAlias(
                new WildcardAlias("Db4odoc.CrossPlatform.CrossPlatform.*, Db4odoc.CrossPlatform",
                                    "com.db4odoc.crossplatform.*"));
        // #end example

        ObjectContainer container = Db4oClientServer.openClient(configuration,
                "localhost", 1337, "sa", "sa");


        try {
            container.store(new Person("Joe", "Average"));
            container.store(new Person("Noel", "Exceptional"));

            for (Object person : container.query(Person.class)) {
                System.out.println(person);
            }

//                var query = container.Query();
//                query.Constrain(typeof (Person));
//                query.Descend("firstname").Constrain("Joe");
//                foreach (object person in query.Execute())
//                {
//                    Console.Out.WriteLine(person);
//                }
        } finally {
            container.close();
        }
        System.out.println("Done.");
    }
}
