package com.db4odoc.configuration.basics;

import com.db4o.Db4oEmbedded;
import com.db4o.ObjectContainer;
import com.db4o.ObjectServer;
import com.db4o.config.EmbeddedConfiguration;
import com.db4o.cs.Db4oClientServer;
import com.db4o.cs.config.ClientConfiguration;
import com.db4o.cs.config.ServerConfiguration;


public class ConfigurationBasics {


    public static void main(String[] args) {
        embeddedConfiguration();
        serverConfiguration();
        clientConfiguration();
    }

    private static void embeddedConfiguration() {
        // #example: Configure embedded object container
        EmbeddedConfiguration configuration = Db4oEmbedded.newConfiguration();
        // change the configuration...
        ObjectContainer container = Db4oEmbedded.openFile(configuration,"database.db4o");
        // #end example
        container.close();
    }

    private static void serverConfiguration() {
        // #example: Configure the db4o-server
        ServerConfiguration configuration = Db4oClientServer.newServerConfiguration();
        // change the configuration...
        ObjectServer server = Db4oClientServer.openServer(configuration,"database.db4o",1337);
        // #end example
        server.close();
    }
    private static void clientConfiguration() {
        // #example: Configure a client object container
        ClientConfiguration configuration = Db4oClientServer.newClientConfiguration();
        // change the configuration...
        ObjectContainer container = Db4oClientServer.openClient(configuration,"localhost",1337,"user","pwd");
        // #end example
        container.close();
    }
}
