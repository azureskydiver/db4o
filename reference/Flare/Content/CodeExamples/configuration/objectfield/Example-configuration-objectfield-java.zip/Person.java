package com.db4odoc.configuration.objectfield;

public class Person {
    private String name;
    private Person father;

}
