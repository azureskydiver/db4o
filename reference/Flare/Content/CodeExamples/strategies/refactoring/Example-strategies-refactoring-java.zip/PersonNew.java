package com.db4odoc.strategies.refactoring;


class PersonNew {
    private String sirname = "Joe";

    public String getSirname() {
        return sirname;
    }

    public void setSirname(String sirname) {
        this.sirname = sirname;
    }
}
