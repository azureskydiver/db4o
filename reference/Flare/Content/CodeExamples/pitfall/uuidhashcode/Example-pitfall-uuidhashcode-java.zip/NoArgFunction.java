package com.db4odoc.pitfall.uuidhashcode;

public interface NoArgFunction<T> {
    T invoke();
}
