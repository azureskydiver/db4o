Namespace Db4oDoc.Silverlight.Model
    ' #example: fields need to be public to be persisted
    Public Class Person
        Public FirstName As String
        Public SirName As String
    End Class
    ' #end example
End Namespace