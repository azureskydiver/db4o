/* Copyright (C) 2004 - 2007  db4objects Inc.  http://www.db4o.com */

package com.db4odoc.performance;

import java.io.File;
import java.util.ArrayList;

import com.db4o.Db4o;
import com.db4o.ObjectContainer;
import com.db4o.ObjectServer;
import com.db4o.ObjectSet;
import com.db4o.config.Configuration;
import com.db4o.io.MemoryIoAdapter;


public class DeletePerformanceBenchmark {
    
    private static int _count = 100000;
    
    private static int _commitInterval = 1000;
    
    private static int _depth = 3;
    
    private static boolean _isClientServer = false;
    
    private static boolean TCP = true;
    
    private static String _filePath = "performance.db4o";
    
    private static String _host = "localhost";
	
    private static final int PORT = 4477;
    
    
    private ObjectContainer objectContainer;
    
    private ObjectServer objectServer;
    
    
    private long startTime;
    
    
    public static void main(String[] arguments) {
    	new DeletePerformanceBenchmark().setupRun();
//    	new DeletePerformanceBenchmark().runDifferentObjectsTest();
//    	new DeletePerformanceBenchmark().runCommitTest();
//    	new DeletePerformanceBenchmark().runRamDiskTest();
//    	new DeletePerformanceBenchmark().runHardDriveTest();
//    	new DeletePerformanceBenchmark().runClientServerTest();
//    	new DeletePerformanceBenchmark().runInheritanceTest();
    	new DeletePerformanceBenchmark().runDeleteDepthTest();
    }
    // end main
    
    private void runCommitTest(){
    	System.out.println("Delete test with different commit frequency");
    	
    	configureForCommitTest();
    	initForCommitTest();
    	
    	clean();
    	System.out.println("Test delete all:");
    	open();
    	store();
    	deleteAll();
    	close();
    	
    	
    	
    	clean();
    	System.out.println("Test delete all with commit after each " + _commitInterval + " objects:");
    	open();
    	store();
    	deleteAllWithCommit();
    	close();
    	
    	
    }
    // end runCommitTest

    private void deleteAllWithCommit() {
    	ObjectSet result = objectContainer.queryByExample(null);
    	ArrayList<Long> ids = new ArrayList<Long>();
    	for (Object obj: result){
    		ids.add(objectContainer.ext().getID(obj));
    	}
    	startTimer();
    	int i = 0;
    	for (long id: ids){
    		objectContainer.delete(objectContainer.ext().getByID(id));
    		if (i++ > _commitInterval){
    			objectContainer.commit();
    			i = 0;
    		}
    	}
    	objectContainer.commit();
    	stopTimer("Deleted all objects");
	}
    // end deleteAllWithCommit

	private void deleteAll() {
		ObjectSet result = objectContainer.queryByExample(null);
    	ArrayList<Long> ids = new ArrayList<Long>();
    	for (Object obj: result){
    		ids.add(objectContainer.ext().getID(obj));
    	}
    	startTimer();
    	for (long id: ids){
    		objectContainer.delete(objectContainer.ext().getByID(id));
    	}
    	objectContainer.commit();
    	stopTimer("Deleted all objects");
	}
    // end deleteAll

	private void selectAll() {
		startTimer();
    	ObjectSet result = objectContainer.queryByExample(null);
    	for (Object obj: result){
    		//objectContainer.delete(obj);
    	} 
    	//stopTimer("Deleted all objects");
	}
    // end selectAll
	
	private void runRamDiskTest(){
		System.out.println("Delete test: RAM disk");
		
    	configureRamDrive();
    	initForRamDriveTest();
    	clean();
    	open();
    	store();
    	System.out.println("Deleting 1 object of depth " + _depth + " on a RAM drive:");
    	deleteAll();
    	close();
	}
	// end runRamDiskTest
    	
	private void runHardDriveTest(){
		System.out.println("Delete test: hard drive");
		
    	initForHardDriveTest();
    	clean();
    	open();
    	store();
    	System.out.println("Deleting 1 object of depth " + _depth + " on a hard drive:");
    	deleteAll();
    	close();
    }
    // end runHardDriveTest

    private void runClientServerTest(){
    	System.out.println("Delete test: Client/Server environment");
    	int objectsToDelete = 10;
    	
    	configureClientServer();
    	
    	init();
    	clean();
    	open();
    	store();
    	System.out.println("Delete " + objectsToDelete + " of " + _count + " objects [depth " + _depth + "] locally:");
    	deleteAny(objectsToDelete);
    	close();
    	
    	initForClientServer();
    	clean();
    	open();
    	store();
    	System.out.println("Delete " + objectsToDelete + " of " + _count + " objects [depth " + _depth + "] remotely:");
    	deleteAny(objectsToDelete);
    	close();
    }
    // end runClientServerTest

    private void runInheritanceTest(){
    	System.out.println("Delete test: objects with deep inheritance");
    	
    	int objectsToDelete = 10;
    	configure();
    	init();
    	clean();
    	open();
    	store();
    	System.out.println("Deleting " + objectsToDelete + " objects of depth " + _depth);
    	deleteAny(objectsToDelete);
    	close();
    	
    	clean();
    	open();
    	storeInherited();
    	System.out.println("Deleting " + objectsToDelete + " inherited objects of depth " + _depth);
    	deleteAny(objectsToDelete);
    	close();
    	
    }
    // end runInheritanceTest

    private void setupRun(){
    	configure();
    	init();
    	open();
    	storeSimplest();
    	long test_id = selectAny();
    	deleteById(test_id);
    	close();	
    }
    // end setupRun
    
    private void runDifferentObjectsTest(){
    	System.out.println("Delete test with different objects");
    			
    	configure();
    	init();
    	System.out.println("Deleting 1 of " + _count + " objects with " + _depth + " levels of embedded objects:");
    	
    	clean();
    	System.out.println(" - primitive object with int field");
    	open();
    	storeSimplest();
    	deleteAny(10);
    	close();
    	
    	clean();
    	open();
    	System.out.println(" - object with String field");
    	store();
    	deleteAny(10);
    	close();
    	
    	clean();
    	open();
    	System.out.println(" - object with StringBuffer field");
    	storeWithStringBuffer();
    	deleteAny(10);
    	close();
    	
    	clean();
    	open();
    	System.out.println(" - object with int array field");
    	storeWithArray();
    	deleteAny(10);
    	close();
    	
    	clean();
    	open();
    	System.out.println(" - object with ArrayList field");
    	storeWithArrayList();
    	deleteAny(10);
    	close();
    	
    }
    // end runDifferentObjectsTest
    
    private void runDeleteDepthTest(){
    	System.out.println("Delete test with objects of different depth");
    			
    	configureDepthTest();
    	initShallowObject();
    	System.out.println("Deleting 1000 of " + _count + " objects with " + _depth + " levels of embedded objects:");
    	clean();
    	open();
    	store();
    	System.out.println("Amount of objects left: " + countObjects());
    	deleteAny(1000);
    	System.out.println("Amount of objects left: " + countObjects());
    	close();
    	
    	clean();
    	init();
    	System.out.println("Deleting 1000 of " + _count + " objects with " + _depth + " levels of embedded objects:");
    	open();
    	store();
    	System.out.println("Amount of objects left: " + countObjects());
    	deleteAny(1000);
    	System.out.println("Amount of objects left: " + countObjects());
    	close();
    	
    }
    // end runDeleteDepthTest
    
    private int countObjects(){
    	ObjectSet result = objectContainer.queryByExample(null);
    	return result.size();
    }
    // end countObjects
    
    private void deleteAny(int i) {
    	long time = 0;
    	int counter = 0;
    	while (counter++ < i){
    		long id = selectAny();
    		time += deleteById(id);
    	}
    	System.out.println("Deleted " + i + " objects in: " + time + " ms.");
	}
    // end deleteAny

    private long deleteById(long id) {
    	startTimer();
    	Object obj = objectContainer.ext().getByID(id);
    	objectContainer.delete(obj);
    	return stopTimer();
	}
    // end deleteById
    
		private long selectAny() {
		Object obj = objectContainer.queryByExample(null).next();
		return objectContainer.ext().getID(obj);
	}
	// end selectAny
    
    
    private void init(){
    	_count = 10000;
        _depth = 3;
        _isClientServer = false;
        	
    }
    // end init
    
    private void initShallowObject(){
    	_count = 10000;
        _depth = 1;
        _isClientServer = false;
        	
    }
    // end initShallowObject
    
    private void initForClientServer(){
    	_count = 10000;
        _depth = 3;
        _isClientServer = true;
        _host = "localhost";	
    }
    // end initForClientServer
    
    private void initForRamDriveTest(){
    	_count = 30000;
        _depth = 3;
        _filePath = "r:\\performance.db4o";
        _isClientServer = false;
        	
    }
    // end initForRamDriveTest
    
    private void initForHardDriveTest(){
    	_count = 30000;
        _depth = 3;
        _filePath = "performance.db4o";
        _isClientServer = false;
    }
    // end initForHardDriveTest
    
    private void initForCommitTest(){
    	_count = 10000;
    	_commitInterval = 1000;
        _depth = 3;
        _isClientServer = false;
    }
    // end initForCommitTest
    
    private void clean(){
    	new File(_filePath).delete();
    }
    // end clean
    
    private void configure(){
    	Configuration config = Db4o.configure(); 
        config.lockDatabaseFile(false);
        config.io(new MemoryIoAdapter());
        config.flushFileBuffers(false);
    }
    // end configure

    private void configureDepthTest(){
    	Configuration config = Db4o.configure(); 
        config.lockDatabaseFile(false);
        config.io(new MemoryIoAdapter());
        config.flushFileBuffers(false);
        config.objectClass(Item.class).cascadeOnDelete(true);
    }
    // end configureDepthTest
    
    private void configureForCommitTest(){
    	Configuration config = Db4o.configure(); 
        config.lockDatabaseFile(false);
        // the commit information is physically written 
        // and in the correct order
        config.flushFileBuffers(true);
    }
    // end configureForCommitTest

    private void configureIndex(){
    	Configuration config = Db4o.configure(); 
        config.lockDatabaseFile(false);
        config.io(new MemoryIoAdapter());
        config.flushFileBuffers(false);
        config.objectClass(Item.class).objectField("_name").indexed(true);
    }
    // end configureIndex

    private void configureClientServer(){
    	Configuration config = Db4o.configure(); 
        config.lockDatabaseFile(false);
        config.flushFileBuffers(false);
        config.clientServer().singleThreadedClient(true);
    }
    // end configureClientServer

    private void configureRamDrive(){
    	Configuration config = Db4o.configure(); 
        config.lockDatabaseFile(false);
        config.weakReferences(false);
        config.flushFileBuffers(true);
    }
    // end configureRamDrive
    
    private void store(){
        startTimer();
        for (int i = 0; i < _count ;i++) {
            Item item = new Item("load", null);
            for (int j = 1; j < _depth; j++) {
                item = new Item("load", item);
            }
            objectContainer.store(item);
        }
        objectContainer.commit();
        stopTimer("Store "+ totalObjects() + " objects");
    }
    // end store

    private void storeCopy(){
        startTimer();
        for (int i = 0; i < _count ;i++) {
        	ItemCopy item = new ItemCopy("load", null);
            for (int j = 1; j < _depth; j++) {
                item = new ItemCopy("load", item);
            }
            objectContainer.store(item);
        }
        objectContainer.commit();
        stopTimer("Store "+ totalObjects() + " objects");
    }
    // end storeCopy

    private void storeInherited(){
        startTimer();
        for (int i = 0; i < _count ;i++) {
            ItemDerived item = new ItemDerived("load", null);
            for (int j = 1; j < _depth; j++) {
                item = new ItemDerived("load", item);
            }
            objectContainer.store(item);
        }
        objectContainer.commit();
        stopTimer("Store "+ totalObjects() + " objects");
    }
    // end storeInherited

    
    private void storeWithStringBuffer(){
        startTimer();
        for (int i = 0; i < _count ;i++) {
            ItemWithStringBuffer item = new ItemWithStringBuffer(new StringBuffer("load"), null);
            for (int j = 1; j < _depth; j++) {
                item = new ItemWithStringBuffer(new StringBuffer("load"), item);
            }
            objectContainer.store(item);
        }
        objectContainer.commit();
        stopTimer("Store "+ totalObjects() + " objects");
    }
    // end storeWithStringBuffer
    
    private void storeSimplest(){
        startTimer();
        for (int i = 0; i < _count ;i++) {
        	SimplestItem item = new SimplestItem(i, null);
            for (int j = 1; j < _depth; j++) {
                item = new SimplestItem(i, item);
            }
            objectContainer.store(item);
        }
        objectContainer.commit();
        stopTimer("Store "+ totalObjects() + " objects");
    }
    // end storeSimplest
    
    private void storeWithArray(){
        startTimer();
        int[] array = new int[]{1,2,3,4};
        for (int i = 0; i < _count ;i++) {
        	int[] id = new int[]{1,2,3,4};
        	ItemWithArray item = new ItemWithArray(id, null);
            for (int j = 1; j < _depth; j++) {
            	int[] id1 = new int[]{1,2,3,4};
                item = new ItemWithArray(id1, item);
            }
            objectContainer.store(item);
        }
        objectContainer.commit();
        stopTimer("Store "+ totalObjects() + " objects");
    }
    // end storeWithArray
    
    private void storeWithArrayList(){
    	startTimer();
    	ArrayList idList = new ArrayList();
    	idList.add(1);
    	idList.add(2);
    	idList.add(3);
    	idList.add(4);
        for (int i = 0; i < _count ;i++) {
        	ArrayList ids = new ArrayList();
        	ids.addAll(idList);
        	ItemWithArrayList item = new ItemWithArrayList(ids, null);
            for (int j = 1; j < _depth; j++) {
            	ArrayList ids1 = new ArrayList();
            	ids1.addAll(idList);
            	item = new ItemWithArrayList(ids1, item);
            }
            objectContainer.store(item);
        }
        objectContainer.commit();
        stopTimer("Store "+ totalObjects() + " objects");
    }
    // end storeWithArrayList
    
    private int totalObjects(){
    	return _count * _depth;
    }
    // end totalObjects
    
    private void open(){
        if(_isClientServer){
        	int port = TCP ? PORT : 0;
        	String user = "db4o";
        	String password = user;
            objectServer = Db4o.openServer(_filePath, port);
            objectServer.grantAccess(user, password);
            objectContainer = TCP ? Db4o.openClient(_host, port, user,
					password) : objectServer.openClient();
        } else{
            objectContainer = Db4o.openFile(_filePath);
        }
    }
    // end open
    
    private void close(){
        objectContainer.close();
        if(_isClientServer){
            objectServer.close();
        }
    }
    //end close
    
    private void startTimer(){
    	startTime = System.currentTimeMillis();
    }
    // end startTimer
    
    private long stopTimer(){
        long stop = System.currentTimeMillis();
        long duration = stop - startTime;
        return duration;
    }
    // end stopTimer
    
    private void stopTimer(String message){
        long stop = System.currentTimeMillis();
        long duration = stop - startTime;
        System.out.println(message + ": " + duration + "ms");
    }
    // end stopTimer
    
    public static class Item {
        
        public String _name;
        public Item _child;

        public Item(){
            
        }
        
        public Item(String name, Item child){
            _name = name;
            _child = child;
        }
    }
    // end Item

    public static class ItemCopy {
        
        public String _name;
        public ItemCopy _child;

        public ItemCopy(){
            
        }
        
        public ItemCopy(String name, ItemCopy child){
            _name = name;
            _child = child;
        }
    }
    // end ItemCopy

    public static class ItemDerived extends Item {
    	
    	public ItemDerived(String name, ItemDerived child){
            super(name, child);
        }
    }
    // end ItemDerived
    
    public static class ItemWithStringBuffer {
        
        public StringBuffer _name;
        public ItemWithStringBuffer _child;
        
        public ItemWithStringBuffer(){
        }
        
        public ItemWithStringBuffer(StringBuffer name, ItemWithStringBuffer child){
            _name = name;
            _child = child;
        }
    }
    // end ItemWithStringBuffer
    
    public static class SimplestItem {
        
        public int _id;
        public SimplestItem _child;

        public SimplestItem(){
        }
        
        public SimplestItem(int id, SimplestItem child){
            _id = id;
            _child = child;
        }
    }
    // end SimplestItem

    public static class ItemWithArray {
        
        public int[] _id;
        public ItemWithArray _child;
        
        public ItemWithArray(){
        }
        
        public ItemWithArray(int[] id, ItemWithArray child){
            _id = id;
            _child = child;
        }
    }
    // end ItemWithArray
    
    public static class ItemWithArrayList {
        
        public ArrayList _ids;
        public ItemWithArrayList _child;
        
        public ItemWithArrayList(){
        }
        
        public ItemWithArrayList(ArrayList ids, ItemWithArrayList child){
            _ids = ids;
            _child = child;
        }
    }
    // end ItemWithArrayList
}
