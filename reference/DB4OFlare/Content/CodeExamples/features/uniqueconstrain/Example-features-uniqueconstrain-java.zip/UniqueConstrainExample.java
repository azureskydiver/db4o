package com.db4odoc.features.uniqueconstrain;

import com.db4o.Db4oEmbedded;
import com.db4o.ObjectContainer;
import com.db4o.ObjectServer;
import com.db4o.config.EmbeddedConfiguration;
import com.db4o.constraints.UniqueFieldValueConstraint;
import com.db4o.constraints.UniqueFieldValueConstraintViolationException;
import com.db4o.cs.Db4oClientServer;
import com.db4o.cs.config.ClientConfiguration;
import com.db4o.cs.config.ServerConfiguration;

import java.io.File;


public class UniqueConstrainExample {

    public static void main(String[] args) {
        new File("database.db4o").delete();
        uniqueContrainsOnCS();
        //uniqueConstrainOnEmbedded();
    }

    private static void uniqueContrainsOnCS(){
        ServerConfiguration config = Db4oClientServer.newServerConfiguration();
        config.common().objectClass(UniqueId.class).objectField("id").indexed(true);
        config.common().add(new UniqueFieldValueConstraint(UniqueId.class, "id"));

        final ObjectServer server = Db4oClientServer.openServer(config, "database.db4o", 8080);
        try{
            server.grantAccess("dba","dba");

            final ClientConfiguration clientCfg = Db4oClientServer.newClientConfiguration();

            final ObjectContainer container = Db4oClientServer.openClient(clientCfg, "localhost", 8080, "dba", "dba");

            container.store(new UniqueId(44));
            // #example: Violating the constrain throws an exception
            container.store(new UniqueId(42));
            container.store(new UniqueId(42));
            try {
                container.commit();
            } catch (UniqueFieldValueConstraintViolationException e) {
                e.printStackTrace();
            }

        } finally {
            server.close();
        }


    }

    private static void uniqueConstrainOnEmbedded() {
        EmbeddedConfiguration config = Db4oEmbedded.newConfiguration();
        // #example: Add the index the field and then the unique constrain
        config.common().objectClass(UniqueId.class).objectField("id").indexed(true);
        config.common().add(new UniqueFieldValueConstraint(UniqueId.class, "id"));
        // #end example
        ObjectContainer container = Db4oEmbedded.openFile(config, "database.db4o");
        try {
            container.store(new UniqueId(44));
            // #example: Violating the constrain throws an exception
            container.store(new UniqueId(42));
            container.store(new UniqueId(42));
            try {
                container.commit();
            } catch (UniqueFieldValueConstraintViolationException e) {
                e.printStackTrace();
            }
            // #end example
        } finally {
            container.close();
        }
    }


    private static class UniqueId {
        private final int id;

        private UniqueId(int id) {
            this.id = id;
        }
    }
}
