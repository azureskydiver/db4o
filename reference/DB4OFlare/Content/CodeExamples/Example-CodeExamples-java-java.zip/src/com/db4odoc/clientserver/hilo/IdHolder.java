package com.db4odoc.clientserver.hilo;


abstract class IdHolder {
    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
