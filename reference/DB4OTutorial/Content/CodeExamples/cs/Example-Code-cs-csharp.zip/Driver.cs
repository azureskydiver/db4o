namespace Db4oTutorialCode.Code.ClientServer
{
    // #example: Domain model for drivers
    public class Driver
    {
        private string name;
        private readonly Car mostLovedCar;

        public Driver(string name)
        {
            this.name = name;
        }

        public Driver(string name, Car mostLovedCar)
        {
            this.name = name;
            this.mostLovedCar = mostLovedCar;
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public Car MostLovedCar
        {
            get { return mostLovedCar; }
        }
    }
    // #end example
}