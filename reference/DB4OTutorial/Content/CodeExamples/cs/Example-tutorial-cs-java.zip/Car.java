package com.db4odoc.tutorial.cs;


// #example: Domain model for cars
public class Car {
    private String carName;

    public Car(String carName) {
        this.carName = carName;
    }

    public String getCarName() {
        return carName;
    }
}
// #end example
