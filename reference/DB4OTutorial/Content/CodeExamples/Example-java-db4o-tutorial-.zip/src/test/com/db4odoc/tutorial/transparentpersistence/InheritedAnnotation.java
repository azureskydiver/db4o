package com.db4odoc.tutorial.transparentpersistence;


public class InheritedAnnotation extends ClassWithAnnotation {
}
