package com.db4odoc.drs.vod;


import com.db4o.ObjectContainer;
import com.db4o.ObjectServer;
import com.db4o.ObjectSet;
import com.db4o.config.ConfigScope;
import com.db4o.cs.Db4oClientServer;
import com.db4o.cs.config.ServerConfiguration;
import com.db4o.drs.Replication;
import com.db4o.drs.ReplicationProvider;
import com.db4o.drs.ReplicationSession;
import com.db4o.drs.db4o.Db4oEmbeddedReplicationProvider;
import com.db4o.drs.versant.VodDatabase;
import com.db4o.drs.versant.VodReplicationProvider;
import com.db4o.drs.versant.jdo.reflect.JdoReflector;
import com.db4o.io.PagingMemoryStorage;

import javax.jdo.PersistenceManager;
import javax.jdo.PersistenceManagerFactory;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ReplicationMediator {
    private static final int INTERVAL_IN_MILLISECONDS = 10000;
    private final Timer timer = new Timer(false);
    private final Lock lock = new ReentrantLock();

    private final ObjectServer mediationServer = openServer();

    private static ObjectServer openServer() {
        ServerConfiguration configuration = Db4oClientServer.newServerConfiguration();
        configuration.file().storage(new PagingMemoryStorage());
        configuration.file().generateCommitTimestamps(true);
        configuration.file().generateUUIDs(ConfigScope.GLOBALLY);
        configuration.common().reflectWith(new JdoReflector(Thread.currentThread().getContextClassLoader()));
        ObjectServer server = Db4oClientServer.openServer(configuration, "!In:Memory!", 8080);
        server.grantAccess("", "");
        return server;
    }

    public static void main(String[] args) {
        PersistenceManagerFactory factory = JDOUtilities.createPersistenceFactory();
        JDOUtilities.inTransaction(factory, new JDOTransaction() {
            public void invoke(PersistenceManager manager) {
                manager.newQuery(Pilot.class).deletePersistentAll();
            }
        });
        new ReplicationMediator().start();
    }

    private void start() {
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                kickOfReplication();
            }
        }, 0, INTERVAL_IN_MILLISECONDS);
    }

    private void kickOfReplication() {
        if (lock.tryLock()) {
            try {
                executeReplication();
            } finally {
                lock.unlock();
            }
        }

    }

    private void executeReplication() {
        PersistenceManagerFactory factory = JDOUtilities.createPersistenceFactory();
        VodDatabase centralDatabase = JDOUtilities.createDatabase(factory);
        VodReplicationProvider provider = new VodReplicationProvider(centralDatabase);
        provider.listenForReplicationEvents(Pilot.class, Car.class);

        ReplicationProvider mediatorReplication
                = new Db4oEmbeddedReplicationProvider(this.mediationServer.ext().objectContainer());

        ReplicationSession session = Replication.begin(provider, mediatorReplication);
        replicate(session, provider.objectsChangedSinceLastReplication());
        replicate(session, mediatorReplication.objectsChangedSinceLastReplication());
        session.commit();

        onVOD(factory);
        onVOD(this.mediationServer.openClient());
    }

    private void onVOD(ObjectContainer objectContainer) {
        ObjectSet<Pilot> ps = objectContainer.query(Pilot.class);
        System.out.println("On Intermediate: " +ps.size());
        for (Pilot p : ps) {
            System.out.println("vod"+p);
        }
        objectContainer.close();
    }

    private void onVOD(PersistenceManagerFactory factory) {
        PersistenceManager manager = factory.getPersistenceManager();
        manager.currentTransaction().begin();
        List<Pilot> ps = (List<Pilot>)manager.newQuery(Pilot.class).execute();
        System.out.println("On vod: " +ps.size());
        for (Pilot p : ps) {
            System.out.println("vod"+p);
        }
         manager.currentTransaction().commit();
        manager.close();
    }

    private void replicate(ReplicationSession session, ObjectSet objectSet) {
        for (Object object : objectSet) {
            session.replicate(object);
        }
    }
}
