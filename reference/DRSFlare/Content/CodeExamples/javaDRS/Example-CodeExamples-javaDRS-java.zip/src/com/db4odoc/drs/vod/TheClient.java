package com.db4odoc.drs.vod;

import com.db4o.Db4oEmbedded;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import com.db4o.config.ConfigScope;
import com.db4o.config.EmbeddedConfiguration;
import com.db4o.cs.Db4oClientServer;
import com.db4o.drs.Replication;
import com.db4o.drs.ReplicationProvider;
import com.db4o.drs.ReplicationSession;
import com.db4o.drs.db4o.Db4oClientServerReplicationProvider;
import com.db4o.drs.db4o.Db4oEmbeddedReplicationProvider;

import java.io.File;

/**
 * @author roman.stoffel@gamlor.info
 * @since 09.03.11
 */
public class TheClient {

    public static void main(String[] args) {
        new TheClient().replicate();
    }

    private void replicate() {
        new File("local.db4o").delete();
        ObjectContainer local = localContainer("local.db4o");
        local.store(new Pilot("Long Repli-1"+Math.random(),42));
        local.store(new Pilot("Long Repli-2"+Math.random(),42));
        local.store(new Pilot("Long Repli-3"+Math.random(),42));
        local.commit();

        ObjectContainer server = Db4oClientServer.openClient("10.78.74.18", 8080, "", "");
//        ObjectContainer server = localContainer("remote.db4o");

        ReplicationProvider localDB = new Db4oEmbeddedReplicationProvider(local);
        ReplicationProvider serverProvider = new Db4oClientServerReplicationProvider(server);

        ReplicationSession session = Replication.begin(localDB, serverProvider);
        replicate(session,localDB.objectsChangedSinceLastReplication());
        replicate(session,serverProvider.objectsChangedSinceLastReplication());
        session.commit();


         local.close();
          server.close();
    }

    private void replicate(ReplicationSession session, ObjectSet objectSet) {
        for (Object object : objectSet) {
            System.out.println("Replicate "+object);
            session.replicate(object);
            try {
                Thread.sleep(3500);
            } catch (InterruptedException e) {

            }
        }
    }

    private ObjectContainer localContainer(String dbName){
        EmbeddedConfiguration configuration = Db4oEmbedded.newConfiguration();
        configuration.file().generateCommitTimestamps(true);
        configuration.file().generateUUIDs(ConfigScope.GLOBALLY);
        return Db4oEmbedded.openFile(configuration,dbName);
    }
}
