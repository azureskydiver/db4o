#!/bin/sh
java -classpath buildrename.jar:scala-library.jar com.db4o.buildrename.BuildPrepareConsoleMain $*
