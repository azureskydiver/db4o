/* Copyright (C) 2005   db4objects Inc.   http://www.db4o.com */

using System.Reflection;
using System.Runtime.CompilerServices;
[assembly: AssemblyTitle("db4o - database for objects")]
[assembly: AssemblyDescription("db4o 4.5.003 .NET")]
[assembly: AssemblyConfiguration(".NET")]
[assembly: AssemblyCompany("db4objects Inc., San Mateo, CA, USA")]
[assembly: AssemblyProduct("db4o - database for objects")]
[assembly: AssemblyCopyright("db4o 2005")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]	
[assembly: AssemblyVersion("4.5.003")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]
