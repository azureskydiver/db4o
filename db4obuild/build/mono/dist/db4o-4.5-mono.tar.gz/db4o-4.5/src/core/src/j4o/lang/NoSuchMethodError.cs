/* Copyright (C) 2004   db4objects Inc.   http://www.db4o.com */

using System;

namespace j4o.lang {

    public class NoSuchMethodError : Exception {
    }
}
