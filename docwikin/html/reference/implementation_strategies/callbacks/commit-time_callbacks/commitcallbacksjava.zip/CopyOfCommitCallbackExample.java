/* Copyright (C) 2007 db4objects Inc. http://www.db4o.com */

package com.db4odoc.commitcallbacks;

import java.io.File;
import java.util.Iterator;

import com.db4o.Db4o;
import com.db4o.ObjectContainer;
import com.db4o.ObjectServer;
import com.db4o.ObjectSet;
import com.db4o.events.CommitEventArgs;
import com.db4o.events.Event4;
import com.db4o.events.EventArgs;
import com.db4o.events.EventListener4;
import com.db4o.events.EventRegistry;
import com.db4o.events.EventRegistryFactory;
import com.db4o.ext.Db4oException;
import com.db4o.ext.ObjectInfo;
import com.db4o.ext.ObjectInfoCollection;
import com.db4o.query.Query;


public class CopyOfCommitCallbackExample {
	
	private static final String DB4O_FILE_NAME = "test.container";
	private static ObjectServer _server;
	
	public static void main(String[] args) {
		storeObjects();
	}
	// end main

	private static ObjectServer server(){
		if (_server == null){
			_server = Db4o.openServer(DB4O_FILE_NAME, 0);
		} 
		return _server;
	}
	// end server
	
	private static void configure(ObjectContainer client){
		EventRegistry registry =  EventRegistryFactory.forObjectContainer((ObjectContainer)client);
		// register an event handler, which will check object uniqueness on commit
		registry.committing().addListener(new EventListener4() {
			public void onEvent(Event4 e, EventArgs args) {
				CommitEventArgs commitArgs = ((CommitEventArgs) args);
				checkUniqueness(commitArgs.added());
				checkUniqueness(commitArgs.updated());
			}
		});
	}
	// end configure
	
	private static void checkUniqueness(ObjectInfoCollection collection){
		Iterator iterator = (Iterator)collection.iterator();
		while (iterator.hasNext()){
			ObjectInfo info = (ObjectInfo)iterator.next();
			if (info.getObject() instanceof Item){
				Item item  = (Item)info.getObject();
				
				Query query = ((ObjectContainer)server()).query();
				query.constrain(Item.class);
				query.descend("_word").constrain(item.getWord());
				ObjectSet found = query.execute();
				while (found.hasNext()){
					if (((Item)found.next()).getNumber() == item.getNumber()){
						throw new Db4oException("Object is not unique: " + item);
					}
				}
			}
		}

	}
	// end checkUniqueness
	
	private static void storeObjects(){
		new File(DB4O_FILE_NAME).delete();
		ObjectServer server = server();
		
		Item item1 = null;
		Item item2  = null;
		try {
			ObjectContainer client1 = server.openClient();
			configure(client1);
			try {
				// creating and storing item1 to the database
				item1 = new Item(1, "one");
				client1.set(item1);
				ObjectContainer client2 = server.openClient();
				configure(client2);
				try {
					// creating and storing item2 with the same fields to the database
					item2 = new Item(1, "one");
					client2.set(item2);
					// commit the changes
					client2.commit();
				} catch (Db4oException ex){
					System.out.println("Error committing client2: " + item2 +  " is not unique");
					client2.rollback();
				} finally {
					client2.close();
				}
				// Item(1,"one") is already in the database: commit will fail
				client1.commit();
			} catch (Db4oException ex){
				System.out.println("Error committing client1: " + item1 +  " is not unique");
				client1.rollback();
			} finally {
				client1.close();
			}
		} finally {
			server.close();
		}
	}
	// end storeObjects
	
}
