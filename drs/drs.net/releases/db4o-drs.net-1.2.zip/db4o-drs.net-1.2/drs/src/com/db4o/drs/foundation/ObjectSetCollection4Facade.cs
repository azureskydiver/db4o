namespace com.db4o.drs.foundation
{
	public class ObjectSetCollection4Facade : ObjectSetAbstractFacade
	{
	}
}