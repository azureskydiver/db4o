namespace com.db4o.drs.inside
{
	internal class ObjectStateImpl : com.db4o.drs.ObjectState
	{
		private object _object;

		private bool _isNew;

		private bool _wasModified;

		private long _modificationDate;

		public virtual object GetObject()
		{
			return _object;
		}

		public virtual bool IsNew()
		{
			return _isNew;
		}

		public virtual bool WasModified()
		{
			return _wasModified;
		}

		public virtual long ModificationDate()
		{
			return _modificationDate;
		}

		internal virtual void SetAll(object obj, bool isNew, bool wasModified, long modificationDate
			)
		{
			_object = obj;
			_isNew = isNew;
			_wasModified = wasModified;
			_modificationDate = modificationDate;
		}

		public override string ToString()
		{
			return "ObjectStateImpl{" + "_object=" + _object + ", _isNew=" + _isNew + ", _wasModified="
				 + _wasModified + ", _modificationDate=" + _modificationDate + '}';
		}
	}
}
