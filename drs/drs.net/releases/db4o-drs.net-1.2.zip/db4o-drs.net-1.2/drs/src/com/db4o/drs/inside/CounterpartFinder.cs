namespace com.db4o.drs.inside
{
	public interface CounterpartFinder
	{
		object FindCounterpart(object original);
	}
}
