namespace com.db4o.drs.inside.traversal
{
	public interface Visitor
	{
		bool Visit(object @object);
	}
}
