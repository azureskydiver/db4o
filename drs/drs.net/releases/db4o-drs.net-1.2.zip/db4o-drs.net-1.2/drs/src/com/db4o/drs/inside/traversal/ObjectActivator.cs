namespace com.db4o.drs.inside.traversal
{
	public interface ObjectActivator
	{
		void Activate(object @object);
	}
}
