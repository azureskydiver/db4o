namespace com.db4o.drs.inside
{
	public interface TestableReplicationProvider : com.db4o.drs.ReplicationProvider, 
		com.db4o.drs.inside.SimpleObjectContainer
	{
	}
}
