/* Copyright (C) 2004 - 2006 db4objects Inc. http://www.db4o.com */

package com.db4odoc.f1.lists;

import java.util.ArrayList;
import java.util.List;

public class CollectionFactory {
	public static List newList(){
		return  new ArrayList();
	}
}
