/* Copyright (C) 2004 - 2006 db4objects Inc. http://www.db4o.com */

class C4 {
  private String s;
  private transient int i;

  private C4(String s) {
    this.s=s;
    this.i=s.length();
  }

  public String toString() {
    return s+i;
  }
} 
