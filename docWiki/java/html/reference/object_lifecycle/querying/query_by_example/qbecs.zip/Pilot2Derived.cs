/* Copyright (C) 2007 db4objects Inc. http://www.db4o.com */

namespace Db4objects.Db4odoc.QBE
{
    class Pilot2Derived : Pilot2
    {
        public Pilot2Derived(string name, int points):base (name, points)
        {
        }
    }
}
