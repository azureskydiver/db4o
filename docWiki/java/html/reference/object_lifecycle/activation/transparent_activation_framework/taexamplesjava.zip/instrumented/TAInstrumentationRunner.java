/* Copyright (C) 2007  db4objects Inc.  http://www.db4o.com */

package com.db4odoc.taexamples.instrumented;

import java.lang.reflect.Method;
import java.net.URL;

import com.db4o.instrumentation.BloatClassEdit;
import com.db4o.instrumentation.BloatInstrumentingClassLoader;
import com.db4o.instrumentation.ByNameClassFilter;
import com.db4o.instrumentation.ClassFilter;
import com.db4o.ta.instrumentation.InjectTransparentActivationEdit;

public class TAInstrumentationRunner {

	public static void main(String[] args) throws Exception {
		// list the classes that need to be instrumented
		ClassFilter filter = new ByNameClassFilter(new String[] { SensorPanelTA.class.getName() });
		// inject TA awareness
		BloatClassEdit edit = new InjectTransparentActivationEdit(filter);
		// get test class and run main method
		BloatInstrumentingClassLoader loader = new BloatInstrumentingClassLoader(new URL[]{}, TAInstrumentationRunner.class.getClassLoader(), filter, edit);
		Class mainClass = loader.loadClass(TAInstrumentationExample.class.getName());
		Method mainMethod = mainClass.getMethod("main", new Class[]{ String[].class });
		mainMethod.invoke(null, new Object[]{ new String[]{} });
	}
	// end main
}
