package com.db4odoc.commitcallbacks;

public class Pilot {

	private String name;
	
	public String getName() {
		return name;
	}

	public Pilot(String name) {
		this.name = name;
	}
}