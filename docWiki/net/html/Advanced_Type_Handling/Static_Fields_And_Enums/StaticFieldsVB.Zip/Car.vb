' Copyright (C) 2004 - 2006 db4objects Inc. http://www.db4o.com 
Imports System
Imports System.Drawing

Namespace Db4objects.Db4odoc.StaticFields
    Public Class Car
        Public _color As Color
    End Class
End Namespace