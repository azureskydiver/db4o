' Copyright (C) 2004 - 2006 db4objects Inc. http://www.db4o.com 
Namespace Db4objects.Db4odoc.Enums
    Enum DoorStateInit
        Open = 1
        Closed = 2
    End Enum
End Namespace