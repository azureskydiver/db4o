' Copyright (C) 2004 - 2006 db4objects Inc. http://www.db4o.com 
Namespace Db4objects.Db4odoc.Enums
    Class Door
        Dim _state As DoorState
        Public Sub New(ByVal NewState As DoorState)
            _state = NewState
        End Sub
    End Class
End Namespace
