package com.db4odoc.nqcollection;

import java.io.*;
import java.util.*;

import com.db4o.*;
import com.db4o.query.*;


public class ParametricNQSample {
	private static final String DB4O_FILE_NAME = "paramnq.db4o";


	public static void main(String[] args) {
		new File(DB4O_FILE_NAME).delete();
		ObjectContainer db = Db4o.openFile(DB4O_FILE_NAME);
		try {
			store(db);
			// runtime typed to Data only :(
			runQuery(db, new DataPredicate<DataA>("A"));
			runQuery(db, createPredicateWrong(DataA.class,"A"));
			// runtime typed to DataA explicitly :/
			runQuery(db, new DataPredicate<DataA>(DataA.class,"A"));
			runQuery(db, createPredicateCorrect(DataA.class,"A"));
		}
		finally {
			db.close();
		}
	}

	private static void store(ObjectContainer db) {
		db.set(new DataA("AB", 123));
		db.set(new DataA("BC", 456));
		db.set(new DataB("AC"));
		db.set(new DataB("DC"));
		db.commit();
	}

	private static void runQuery(ObjectContainer db, Predicate<DataA> predicate) {
		List<DataA> result=db.query(predicate);
		System.out.println(result.size());
		try {
			for (DataA dataA : result) {
				System.out.println(dataA);
			} 
		}
		catch (ClassCastException exc) {
			System.out.println(exc);
		}
	}

	@SuppressWarnings("serial")
	private static class DataPredicate<T extends Data> extends Predicate<T> {
		private final String _threshold;
		
		public DataPredicate(String threshold) {
			_threshold = threshold;
		}

		public DataPredicate(Class<T> clazz, String threshold) {
			super(clazz);
			_threshold = threshold;
		}

		public boolean match(T candidate) {
			return candidate.getName().startsWith(_threshold);
		}
	}

	private static <T extends Data> Predicate<T> createPredicateWrong(Class<T> clazz, String threshold) {
		return new DataPredicate<T>(threshold);
	}

	private static <T extends Data> Predicate<T> createPredicateCorrect(Class<T> clazz, String threshold) {
		return new DataPredicate<T>(clazz,threshold);
	}
	
	/************ Class definitions *********************************/
	public abstract static class Data {
		private String name;
		
		public Data(String name) {
			this.name = name;
		}
		public String getName() {
			return name;
		}
	}
	
	public static class DataA extends Data {
		private int points;

		public DataA(String name, int points) {
			super(name);
			this.points = points;
		}

		public String toString() {
			return super.name + "/" + points;
		}
	}
	
	public static class DataB extends Data{
		
		//private String name;
		
		public DataB(String name) {
			super(name);
		}

		public String toString() {
			return super.name ; 
		}
	}
}
