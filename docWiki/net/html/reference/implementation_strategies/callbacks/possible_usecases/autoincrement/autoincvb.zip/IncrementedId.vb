' Copyright (C) 2009 Versant Inc. http://www.db4o.com */

' Singleton class used to keep auotincrement information 
' and give the next available ID on request

Imports System
Imports Db4objects.Db4o
Namespace Db4odoc.Autoincrement

    Class IncrementedId
        Private _no As Integer
        Private Shared _ref As IncrementedId

        Private Sub New()
            _no = 0
        End Sub
        ' end New

        Public Function GetNextID(ByVal db As IObjectContainer) As Integer
            System.Math.Min(System.Threading.Interlocked.Increment(_no), _no - 1)
            db.Store(Me)
            Return _no
        End Function
        ' end GetNextID

        Public Shared Function GetIdObject(ByVal db As IObjectContainer) As IncrementedId
            ' if _ref is not assigned yet:
            If _ref Is Nothing Then
                ' check if there is a stored instance from the previous 
                ' session in the database
                Dim os As IObjectSet = db.QueryByExample(GetType(IncrementedId))
                If os.Count > 0 Then
                    _ref = CType(os.Next, IncrementedId)
                End If
            End If
            If _ref Is Nothing Then
                ' create new instance and store it
                Console.WriteLine("Id object is created")
                _ref = New IncrementedId
                db.Store(_ref)
            End If
            Return _ref
        End Function
        ' end GetIdObject

    End Class
End Namespace