' Copyright (C) 2009 Versant Inc. http://www.db4o.com 
Namespace Db4odoc.Autoincrement

    Class TestObject
        Inherits CountedObject
        Private _name As String

        Public Sub New(ByVal name As String)
            _name = name
        End Sub

        Public Overloads Overrides Function ToString() As String
            Return _name + "/" + _id.ToString()
        End Function
    End Class
End Namespace