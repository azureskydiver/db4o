' Copyright (C) 2004 - 2006 db4objects Inc. http://www.db4o.com 
Imports System

Namespace Db4objects.Db4odoc.SelectivePersistence
    <AttributeUsage(AttributeTargets.Field)> _
    Public Class FieldTransient
        Inherits Attribute
    End Class
End Namespace
